class a
{
public void  nop() {
  while (true) {
	  // Thread.sleep(DURATION);
	  }
}}
